package pl.retsuz.conversions;

public interface GenericNumeralSystem {
    String fromArabic(int val);
    int toArabic(String val);
}
